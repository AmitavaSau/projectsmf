<section class="py-1">
	<div class="row mb-4">
		<div class="col-lg-6 mb-4 mb-lg-0">
			<div class="card h-50">
				<div class="card-header">
					<h2 class="h6 text-uppercase mb-0">PWD TO GENERAL</h2>
				</div>
				<div class="card-body scroll">
					<button type="button" data-from="cat_pw"  data-to="cat_ge" class="btn btn-dark seat-convert ml-3">Convert</button>
				</div>
			</div>
		</div>
				
		<div class="col-lg-6 mb-4 mb-lg-0">
			<div class="card h-50 mb-4">
				<div class="card-header">
					<h2 class="h6 text-uppercase mb-0">ST TO SC</h2>
				</div>
					<div class="card-body">
						<button type="button"  data-to="cat_sc"  data-from="cat_st"  class="btn btn-dark seat-convert ml-3">Convert</button>
				</div>
			</div>
		</div>
		
	</div>
		
</section>
	

<?php
$this->load->view("common/footer");
?>