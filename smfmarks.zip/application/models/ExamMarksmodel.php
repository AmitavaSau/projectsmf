<?php
class ExamMarksmodel extends CI_Model
{

    function __construct()
    {
        parent::__construct();
        $this->load->database();
        $ci = get_instance();
        $ci->load->helper('string');
    }

    function download_marks_student_final($userId)
    {
        $cand_tbl    =    'student_marks_final';

        $this->db->where('std_code', $userId);
        $this->db->update($cand_tbl, array('std_download_status' => 1));
        return TRUE;
    }

    function download_marks_student_pre($userId)
    {
        $cand_tbl    =    'student_marks_pre';

        $this->db->where('std_code', $userId);
        $this->db->update($cand_tbl, array('std_download_status' => 1));
        return TRUE;
    }

    function college($college_code)
    {
        $college_master = 'mast_colleges';
        $this->db->select('col_code,col_name');
        $this->db->from($college_master);
        $this->db->where('col_code', $college_code);
        $query = $this->db->get();
        $dropdowns = $query->result_array();
        $dropDownList[''] = 'Choose College';
        if (count($dropdowns) > 0) {
            foreach ($dropdowns as $dropdown) {

                $dropDownList[$dropdown['col_code']] = $dropdown['col_name'];
            }
        }
        return $dropDownList;
    }

    function course()
    {
        $course_master = 'mast_courses';
        $this->db->select('crs_dept,crs_name');
        $this->db->from($course_master);
        $query = $this->db->get();
        $dropdowns = $query->result_array();
        $dropDownList[''] = 'Choose Course';
        if (count($dropdowns) > 0) {
            foreach ($dropdowns as $dropdown) {

                $dropDownList[$dropdown['crs_dept']] = $dropdown['crs_name'];
            }
        }
        return $dropDownList;
    }

    function paper()
    {
        return array(
            ''    =>    '--Select--',
            'paper_1_marks'    =>    'PAPER I',
            'paper_2_marks'    =>    'PAPER II',
            'paper_3_marks'    =>    'PAPER III',
            'paper_4_marks'    =>    'PAPER IV'
        );
    }

    function paper_segments()
    {
        return array(
            ''    =>    '--Select--',
            'IA THEORY'        =>    'INTERNAL ASSESSMENT MARKS THEORY',
            'IA ORAL'          =>    'INTERNAL ASSESSMENT MARKS ORAL',
            'IA PRACTICAL'     =>    'INTERNAL ASSESSMENT MARKS PRACTICAL',
            'IA ORAL PRACTICAL'     =>    'INTERNAL ASSESSMENT MARKS ORAL PRACTICAL',
            'IA CLINICAL ASSESSMENT'     =>    'INTERNAL ASSESSMENT MARKS CLINICAL ASSESSMENT',

            'WT THEORY'        =>    'WRITTEN TEST MARKS THEORY',
            'WT ORAL'          =>    'WRITTEN TEST MARKS ORAL',
            'WT PRACTICAL'     =>    'WRITTEN TEST MARKS PRACTICAL',
            'WT ORAL PRACTICAL'     =>    'WRITTEN TEST MARKS ORAL PRACTICAL',
            'WT CLINICAL ASSESSMENT'     =>    'WRITTEN TEST MARKS CLINICAL ASSESSMENT',

            //'ATTENDANCE'     =>    'ATTENDANCE'
        );
    }


    public function get_candidates_preliminary($inst_code, $course_name, $cand_paper, $cand_paper_seg)
    {
        $cand_table = 'cand_preliminary_candidate';
        $marks_table = 'cand_preliminary_candidate_marks';

        $field_name = $cand_paper . "_" . strtolower(str_replace(' ', '_', $cand_paper_seg));

        if (!$this->db->field_exists($field_name, $marks_table)) {
            $field_name = '"" AS cand_marks_opt,"" AS cand_marks_remarks';
        } else {
            $field_name = $field_name . ' AS cand_marks_opt,' . $field_name . '_remarks AS cand_marks_remarks';
        }


        $this->db->select('cand_preliminary_candidate.*,' . $field_name);
        $this->db->from($cand_table);
        $this->db->join($marks_table, 'pre_cand_code = pre_cand_code_marks', 'left');
        $this->db->where('inst_code', $inst_code);
        $this->db->where('course_name', $course_name);
        $this->db->order_by('pre_slno', 'ASC');

        $query = $this->db->get();
        return $query->result_array();
    }


    public function save_or_update_marks_preliminary($data)
    {

        $marks_table = 'cand_preliminary_candidate_marks';

        $cand_paper = $this->input->post('cand_paper');
        $cand_paper_seg = $this->input->post('cand_paper_seg');

        $field_marks = $cand_paper . "_" . strtolower(str_replace(' ', '_', $cand_paper_seg));
        $field_remarks = $cand_paper . "_" . strtolower(str_replace(' ', '_', $cand_paper_seg) . "_remarks");

        $tbl_data = [
            $field_marks => $data['cand_marks_opt'],
            $field_remarks => $this->input->post('cand_marks_remarks'),
            'pre_cand_code_marks' => $data['pre_cand_code']
        ];


        $this->db->where('pre_cand_code_marks', $data['pre_cand_code']);
        $query = $this->db->get($marks_table);

        if ($query->num_rows() > 0) {
            $this->db->where('pre_cand_code_marks', $data['pre_cand_code']);
            $this->db->update($marks_table, $tbl_data);
        } else {
            $this->db->insert($marks_table, $tbl_data);
        }

        return $this->db->affected_rows() > 0;
    }

    //FOR FINAL

    public function get_candidates_final($inst_code, $course_name, $cand_paper, $cand_paper_seg)
    {
        $cand_table = 'cand_final_candidate';
        $marks_table = 'cand_final_candidate_marks';

        $field_name = $cand_paper . "_" . strtolower(str_replace(' ', '_', $cand_paper_seg));

        if (!$this->db->field_exists($field_name, $marks_table)) {
            $field_name = '"" AS cand_marks_opt,"" AS cand_marks_remarks';
        } else {
            $field_name = $field_name . ' AS cand_marks_opt,' . $field_name . '_remarks AS cand_marks_remarks';
        }


        $this->db->select('cand_final_candidate.*,' . $field_name);
        $this->db->from($cand_table);
        $this->db->join($marks_table, 'pre_cand_code = pre_cand_code_marks', 'left');
        $this->db->where('inst_code', $inst_code);
        $this->db->where('course_name', $course_name);
        $this->db->order_by('pre_slno', 'ASC');

        $query = $this->db->get();
        return $query->result_array();
    }


    public function save_or_update_marks_final($data)
    {

        $marks_table = 'cand_final_candidate_marks';

        $cand_paper = $this->input->post('cand_paper');
        $cand_paper_seg = $this->input->post('cand_paper_seg');

        $field_marks = $cand_paper . "_" . strtolower(str_replace(' ', '_', $cand_paper_seg));
        $field_remarks = $cand_paper . "_" . strtolower(str_replace(' ', '_', $cand_paper_seg) . "_remarks");

        $tbl_data = [
            $field_marks => $data['cand_marks_opt'],
            $field_remarks => $this->input->post('cand_marks_remarks'),
            'pre_cand_code_marks' => $data['pre_cand_code']
        ];


        $this->db->where('pre_cand_code_marks', $data['pre_cand_code']);
        $query = $this->db->get($marks_table);

        if ($query->num_rows() > 0) {
            $this->db->where('pre_cand_code_marks', $data['pre_cand_code']);
            $this->db->update($marks_table, $tbl_data);
        } else {
            $this->db->insert($marks_table, $tbl_data);
        }

        return $this->db->affected_rows() > 0;
    }
}
