<section class="py-3">
	<div class="row mb-4">
		<div class="col-lg-12 mb-4 mb-lg-0">
			<div class="card">
				<div class="card-body">
					<h4 class="text-uppercase mb-0 text-red">You are not authorised to access the page</h4>
				</div>			
            </div>
		</div>
	</div>
</section>

<?php
$this->load->view("common/footer");
?>		